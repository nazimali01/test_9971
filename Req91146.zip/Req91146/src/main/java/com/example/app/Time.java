package com.example.app;

import java.util.Date;

class Time {
  private String updated;
  private Date updatedISO;
  private String updateduk;

  public String getUpdated() {
    return updated;
  }

  public void setUpdated(String updated) {
    this.updated = updated;
  }

  public Date getUpdatedISO() {
    return updatedISO;
  }

  public void setUpdatedISO(Date updatedISO) {
    this.updatedISO = updatedISO;
  }

  public String getUpdateduk() {
    return updateduk;
  }

  public void setUpdateduk(String updateduk) {
    this.updateduk = updateduk;
  }

  @Override
  public String toString() {
    return "Time{" +
        "updated='" + updated + '\'' +
        ", updatedISO=" + updatedISO +
        ", updateduk='" + updateduk + '\'' +
        '}';
  }
}
