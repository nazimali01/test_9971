package com.example.app;

public class BitCoinException extends RuntimeException {

  public BitCoinException(String message) {
    super(message);
  }
}
