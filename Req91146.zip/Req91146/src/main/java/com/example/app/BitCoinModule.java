package com.example.app;

import com.google.inject.AbstractModule;

public class BitCoinModule extends AbstractModule {

  @Override
  protected void configure() {
    bind(BitCoinJsonReader.class).to(BitCoinJsonReaderImpl.class);
  }
}
