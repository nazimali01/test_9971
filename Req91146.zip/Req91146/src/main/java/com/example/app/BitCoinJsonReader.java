package com.example.app;

import org.json.JSONObject;

import java.io.IOException;

interface BitCoinJsonReader {
  JSONObject readJson(String uri) throws IOException;
}
