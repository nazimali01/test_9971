package com.example.app;

import java.util.List;

class BitCoinHistoryPriceModel {
  public List<Float> historicalPrices;
  public String disclaimer;
  public Time time;

  public List<Float> getHistoricalPrices() {
    return historicalPrices;
  }

  public void setHistoricalPrices(List<Float> historicalPrices) {
    this.historicalPrices = historicalPrices;
  }

  public String getDisclaimer() {
    return disclaimer;
  }

  public void setDisclaimer(String disclaimer) {
    this.disclaimer = disclaimer;
  }

  public Time getTime() {
    return time;
  }

  public void setTime(Time time) {
    this.time = time;
  }
}
