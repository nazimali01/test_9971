package com.example.app;

import com.google.inject.Guice;
import com.google.inject.Injector;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Optional;

public class BitCoinApp {
  private static String CURRENT_PRICE_URL = "https://api.coindesk.com/v1/bpi/currentprice/%s.json";
  private static String HISTORICAL_PRICE_URL = "https://api.coindesk.com/v1/bpi/historical/close.json?start=%s&end=%s&currency=%s";
  private final static String EUR = "EUR";
  private final static String USD = "USD";
  private final static String GBP = "GBP";

  public static void main(String[] args) {
    Injector injector = Guice.createInjector(new BitCoinModule());
    BitCoinJsonReader reader = injector.getInstance(BitCoinJsonReader.class);
    BitCoinApi api = new BitCoinApi(reader);

    String currency = getCurrencyCode();
    BitCoinCurrentPriceModel currentPrices = api.getCurrentBitCoinRate(String.format(CURRENT_PRICE_URL, currency));
    BitCoinHistoryPriceModel historyPrices = api.getHistoricalBitCoinRate(String.format(HISTORICAL_PRICE_URL, "2013-09-01", "2013-09-30", currency));

    System.out.println(String.format("BitCoin current rate in requested currency(%s) is: %s", currency, getCurrencyRate(currency, currentPrices.getBpi())));
    Optional<Float> maxPrice = historyPrices.getHistoricalPrices().stream().reduce(Float::max);
    Optional<Float> minPrice = historyPrices.getHistoricalPrices().stream().reduce(Float::min);

    System.out.println(String.format("BitCoin min and max rate in requested currency(%s) is: %s, %s", currency, minPrice.get(), maxPrice.get()));
  }

  private static String getCurrencyCode() {
    try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
      System.out.println("Enter one of the supported currency code EUR/USD/GBP:");
      return validateCurrency(reader.readLine());
    } catch (IOException ioException) {
      throw new BitCoinException(ioException.getMessage());
    }
  }

  private static String validateCurrency(String currency) {
    switch (currency.toUpperCase()) {
      case EUR:
        return EUR;
      case USD:
        return USD;
      case GBP:
        return GBP;
      default:
        throw new BitCoinException(String.format("Entered currency %s not supported yet", currency));
    }
  }

  private static String getCurrencyRate(String currency, Bpi bpi) {
    switch (currency) {
      case EUR:
        return bpi.getEUR().getRate();
      case USD:
        return bpi.getUSD().getRate();
      case GBP:
        return bpi.getGBP().getRate();
      default:
        throw new BitCoinException(String.format("Entered currency %s not supported yet", currency));
    }
  }
}
