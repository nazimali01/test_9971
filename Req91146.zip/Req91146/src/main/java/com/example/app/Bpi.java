package com.example.app;

import com.fasterxml.jackson.annotation.JsonProperty;

class Bpi {
  @JsonProperty("USD")
  private USD USD;
  @JsonProperty("EUR")
  private EUR EUR;
  @JsonProperty("GBP")
  private GBP GBP;

  public USD getUSD() {
    return USD;
  }

  public void setUSD(USD USD) {
    this.USD = USD;
  }

  public EUR getEUR() {
    return EUR;
  }

  public void setEUR(EUR EUR) {
    this.EUR = EUR;
  }

  public GBP getGBP() {
    return GBP;
  }

  public void setGBP(GBP GBP) {
    this.GBP = GBP;
  }
}
