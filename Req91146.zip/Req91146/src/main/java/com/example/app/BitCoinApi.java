package com.example.app;

import com.google.gson.Gson;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class BitCoinApi {
  private static final Gson gson = new Gson();
  private final BitCoinJsonReader bitCoinJsonReader;

  public BitCoinApi(BitCoinJsonReader bitCoinJsonReader) {
    this.bitCoinJsonReader = bitCoinJsonReader;
  }

  public BitCoinCurrentPriceModel getCurrentBitCoinRate(String url) {
    try {
      return convertToCurrentModel(bitCoinJsonReader.readJson(url));
    } catch (IOException exp) {
      throw new BitCoinException(exp.getMessage());
    }
  }

  public BitCoinHistoryPriceModel getHistoricalBitCoinRate(String url) {
    try {
      return convertToHistoryModel(bitCoinJsonReader.readJson(url));
    } catch (IOException exp) {
      throw new BitCoinException(exp.getMessage());
    }
  }

  private BitCoinCurrentPriceModel convertToCurrentModel(JSONObject json) {
    return gson.fromJson(json.toString(),
        BitCoinCurrentPriceModel.class);
  }

  private BitCoinHistoryPriceModel convertToHistoryModel(JSONObject json) {
    List<Float> historicalPrices = new ArrayList();
    JSONObject rateObject = json.getJSONObject("bpi");
    Iterator<String> keys = rateObject.keys();

    while (keys.hasNext()) {
      String key = keys.next();
      historicalPrices.add(rateObject.getFloat(key));
    }

    BitCoinHistoryPriceModel model = new BitCoinHistoryPriceModel();
    // model.setDisclaimer(); // not needed for now.
    // model.setTime();       // not needed for now.
    model.setHistoricalPrices(Collections.unmodifiableList(historicalPrices));

    return model;
  }
}
