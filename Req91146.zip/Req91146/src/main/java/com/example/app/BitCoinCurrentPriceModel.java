package com.example.app;

class BitCoinCurrentPriceModel {
  private Time time;
  private String disclaimer;
  private Bpi bpi;

  public Time getTime() {
    return time;
  }

  public void setTime(Time time) {
    this.time = time;
  }

  public String getDisclaimer() {
    return disclaimer;
  }

  public void setDisclaimer(String disclaimer) {
    this.disclaimer = disclaimer;
  }

  public Bpi getBpi() {
    return bpi;
  }

  public void setBpi(Bpi bpi) {
    this.bpi = bpi;
  }

  @Override
  public String toString() {
    return "BitCoinCurrentPriceModel{" +
        "time=" + time +
        ", disclaimer='" + disclaimer + '\'' +
        ", bpi=" + bpi +
        '}';
  }
}

class EUR {
  private String code;
  private String rate;
  private String description;
  private double rate_float;

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getRate() {
    return rate;
  }

  public void setRate(String rate) {
    this.rate = rate;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public double getRate_float() {
    return rate_float;
  }

  public void setRate_float(double rate_float) {
    this.rate_float = rate_float;
  }

  @Override
  public String toString() {
    return "EUR{" +
        "code='" + code + '\'' +
        ", rate='" + rate + '\'' +
        ", description='" + description + '\'' +
        ", rate_float=" + rate_float +
        '}';
  }
}

class USD {
  private String code;
  private String rate;
  private String description;
  private double rate_float;

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getRate() {
    return rate;
  }

  public void setRate(String rate) {
    this.rate = rate;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public double getRate_float() {
    return rate_float;
  }

  public void setRate_float(double rate_float) {
    this.rate_float = rate_float;
  }

  @Override
  public String toString() {
    return "USD{" +
        "code='" + code + '\'' +
        ", rate='" + rate + '\'' +
        ", description='" + description + '\'' +
        ", rate_float=" + rate_float +
        '}';
  }
}

class GBP {
  private String code;
  private String rate;
  private String description;
  private double rate_float;

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getRate() {
    return rate;
  }

  public void setRate(String rate) {
    this.rate = rate;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public double getRate_float() {
    return rate_float;
  }

  public void setRate_float(double rate_float) {
    this.rate_float = rate_float;
  }
}
